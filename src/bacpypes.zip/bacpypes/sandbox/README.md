## BACpypes Sandbox

This directory is an intentionally disorganized collection of
code used by the developers.

